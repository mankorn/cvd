(function(window, undefined) {

  var jimLinks = {
    "bc4aeabd-014c-40cf-9161-4386c39eb683" : {
      "Flat-button-light" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "509e5f22-5d50-447b-8ea5-920df51da520" : {
      "Text_34" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Text_35" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Rectangle_1" : [
        "509e5f22-5d50-447b-8ea5-920df51da520"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);